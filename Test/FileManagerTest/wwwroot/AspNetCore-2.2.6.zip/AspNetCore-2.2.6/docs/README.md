Contributor documentation
=========================

The primary audience for documentation in this folder is contributors to ASP.NET Core.
If you are looking for documentation on to *use* ASP.NET Core, go to <https://docs.asp.net>.
