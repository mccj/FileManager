Inside sample.zip for Compress storage demo.
